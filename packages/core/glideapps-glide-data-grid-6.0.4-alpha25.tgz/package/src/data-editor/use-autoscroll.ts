import React from "react";
import type { GridMouseCellEventArgs } from "../internal/data-grid/event-args.js";

const maxPxPerMs = 2;
const msToFullSpeed = 1300;

export function useAutoscroll(
    scrollDirection: GridMouseCellEventArgs["scrollEdge"] | undefined,
    scrollRef: React.MutableRefObject<HTMLDivElement | null>,
    onScroll?: () => void
) {
    const speedScalar = React.useRef(0);
    const [xDir, yDir] = scrollDirection ?? [0, 0];
    React.useEffect(() => {
        if (xDir === 0 && yDir === 0) {
            speedScalar.current = 0;
            return;
        }
        let cancelled = false;

        let lastTime = 0;
        const scrollFn = (curTime: number) => {
            if (cancelled) return;
            if (lastTime === 0) {
                lastTime = curTime;
            } else {
                const step = curTime - lastTime;
                speedScalar.current = Math.min(1, speedScalar.current + step / msToFullSpeed);
                const motion = speedScalar.current ** 1.618 * step * maxPxPerMs;
                scrollRef.current?.scrollBy(xDir * motion, yDir * motion);
                lastTime = curTime;
                onScroll?.();
            }
            window.requestAnimationFrame(scrollFn);
        };
        window.requestAnimationFrame(scrollFn);
        return () => {
            cancelled = true;
        };
    }, [scrollRef, xDir, yDir, onScroll]);
}
